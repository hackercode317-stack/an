#include<stdio.h>
struct frmnode
{
    int pno;
}frames[20];
int n;

int page_found(int pno)
{
    int fno;
    for(fno = 0; fno < n ; fno++)
    {
        if(frames[fno].pno == pno)
        return fno;
    }
    return -1;
}

int get_free_frame()
{
    int fno;
    for(fno = 0; fno < n ; fno++)
    {
        if(frames[fno].pno == -1)
        return fno;
    }
    return -1;
}

int next_use(int p_req[], int from, int sizem int pno)
{
    int k
    for(k = from; k < size)
}

int main()
{
    int i,j,page_faults = 0;  
    int p_req[] = {2,5,2,8,5,4,1,2,3,2,6,1,2,5,9,8};
    int size = sizeof(p_req)/sizeof(int);
    int fno;
    printf("\n Total references : %d ",size);
    printf("\n Enter how many Frames : ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
      {  frames[i].pno = -1;
        frames[i].freq = 0;
      }
    printf("\n%-10s","Page NO");
    printf("%-7s","F1");
    printf("%-7s","F3");
    printf("%-7s","F3");
     printf("%-7s\n","Page Faults");
     printf("=============================================\n");
     for(i=0;i<size;i++)
     {
        j = page_found(p_req[i]);
        
        if(j==-1)
        {
            page_faults++;
            j = get_free_frame();
            if(j==-1)
                j = get_mfu_frame();
            frames[j].pno = p_req[i];
            frames[j].freq = 1;
            printf("%4d\t",p_req[i]);
            for(fno = 0; fno < n ; fno ++)
            {
                if(frames[fno].pno == -1)
                    printf("%-7s", " -");
                else
                    printf("%-7d", frames[fno].pno);
            }
            printf("%-7s\n"," YES");
        }

        else{
            frames[j].freq++;
          printf("%4d\t",p_req[i]);

            for(fno = 0; fno < n ; fno ++)
            {
                if(frames[fno].pno == -1)
                    printf("%-7s", " -");
                else
                    printf("%-7d", frames[fno].pno);
            }
            printf("%-7s\n"," NO");
        }
     }

     printf("\n Total Number of Page Faults : %d",page_faults);
}